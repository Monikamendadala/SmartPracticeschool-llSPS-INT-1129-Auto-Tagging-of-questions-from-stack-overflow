from __future__ import division, print_function
from flask import Flask, redirect, url_for, request, render_template, jsonify
import json
from keras.models import load_model
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
import numpy as np
import os
app = Flask(__name__, static_url_path='')
def model_predict(f, model):
    text_labels = encoder.classes_ 
    prediction = model.predict(np.array(f))
    predicted_label = text_labels[np.argmax(prediction)]
    print(test_posts.iloc[f][:50], "...")
    print('Actual label:' + test_tags.iloc[i])
    print("Predicted label: " + predicted_label + "\n")
    return predicted_label
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    question = request.form["question"]
    model = load_model('model.h5')
    preds = model_predict(question, model)
    print("preds : "+str(preds))
    print(result)
    return result
if __name__ == '__main__':
    port = int(os.getenv('PORT', 8000))
    app.run(host='0.0.0.0', port=port, debug=True)



